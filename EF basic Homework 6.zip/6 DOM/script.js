function first() {
   document.getElementById('appear').innerText = "Brilliant! I appeared here!"
}

function change() {
   let task2 = document.querySelectorAll('.yyy')
   for (let i = 1; i < task2.length; i++) {
      task2[i].innerText = i 
   }
   }

   function color() {
      let task3 = document.querySelectorAll('p')
      task3[3].style.color = "gold"
   }