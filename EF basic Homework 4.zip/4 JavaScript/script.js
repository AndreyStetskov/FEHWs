// 1. Написать программу, которая запрашивает у пользователя его возраст (в годах) и выводит, сколько ему минут.
let age = prompt("How old are you full?")
let leapYear = Math.floor(age / 4)
let minut = ((age - leapYear) * 365 + leapYear * 366) * 24 * 60
console.log(`You live at least ${minut} minutes`); 

// 2. Написать программу, которая считывает через prompt число и выводит в консоль ее квадрат
let number = prompt("Enter your number, please")
console.log("The square of your number is " + number * number); 

// 3. Написать программу, которая считывает два числа
// (объявляем две переменные и записываем туда результат работы двух вызовов prompt)
// и выводит их сумму.
let number1 = prompt("Enter your first number, please")
console.log("Your first number is " + number1); 
let number2 = prompt("Enter your second number, please")
console.log("Your second number is " + number2); 
console.log(`The sum of your numbers equals ${Number(number1) + Number(number2)}`); 